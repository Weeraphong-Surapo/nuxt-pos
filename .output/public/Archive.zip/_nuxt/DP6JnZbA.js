import{_ as e,o,c as t}from"./BQPsq2sp.js";const c={};function s(r,n,a,_,p,f){return o(),t("div")}const i=e(c,[["render",s]]);export{i as default};
