import{a7 as s,r as u}from"./BQPsq2sp.js";const n=s("auth",()=>{const e=u(null);function r(t){e.value=t}return{setUser:r,user:e}});export{n as u};
